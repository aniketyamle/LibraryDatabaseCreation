Team Members:
Aniket Yamle - 1002069230
Amlan Alok - 1001855861


Part 1:


EER Diagram is saved to EER-Schema-Diagram.png file

Documentation report is saved to documentation_report_part1.text


Part 2: 
Relational Database Schema of EER diagram is saved in Relational_Database_Schema.png file.

We have also provided the library_v1.mwb file which contains our relational database schema.

The create table statements can be found in create_library.sql

